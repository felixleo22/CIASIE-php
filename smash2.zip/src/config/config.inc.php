<?php
global $BASE_URL;

$config=array();

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

/**
 * Configuaration pour la connexion à la base de données
 */
$config["db"] = [
    'driver' => "mysql",
    'host' => "localhost",
    'database' => "smash2",
    'username' => "smash2DB",
    'password' => "root",
    'charset' => "utf8",
    'collation' => "utf8_unicode_ci",
    'prefix' => ''
];