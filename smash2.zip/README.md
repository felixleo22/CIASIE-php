# PROJET SMASH2

Antoine PINOT  
Léo FELIX  
Simon DAL PONTE  
Hugo JAHNKE  

# EXPORT DE LA BASE DE DONNEES
importer le fichier **db/smash2.sql**

puis configurer les identifiants de connexion dans le fichier **src/config/config.inc.php**

# compte admins
le compte administrateur par défault est :

**login :** root  
**password :** root  
